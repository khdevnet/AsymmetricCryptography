﻿namespace BankApi.Library.Models
{
    public class PaymentResult
    {
        public int TransactionId { get; set; }

        public string Message { get; set; }
    }
}