﻿namespace BankApi.Library.Models
{
    public class CreditCard
    {
        public string Number { get; set; }

        public string Date { get; set; }

        public string Cvv { get; set; }
    }
}