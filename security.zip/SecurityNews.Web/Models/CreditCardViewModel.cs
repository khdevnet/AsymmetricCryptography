﻿namespace SecurityNews.Web.Models
{
    public class CreditCardViewModel
    {
        public string Number { get; set; }

        public string Date { get; set; }

        public string Cvv { get; set; }
    }
}